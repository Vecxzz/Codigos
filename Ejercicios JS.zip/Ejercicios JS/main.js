// Ejercicio 1
const userInfo = document.getElementById('userInfo');
const url = 'https://randomuser.me/api/';

fetch(url)
    .then(response => response.json())
    .then(data => {
        const usuario = data.results[0];
        const nombre = `${usuario.name.first} ${usuario.name.last}`;
        const ubicacion = `${usuario.location.city}, ${usuario.location.country}`;
        const imagen = `${usuario.picture.large}`;
        userInfo.innerHTML =
            `<p>Nombre: ${nombre}</p>
            <p>Ubicación: ${ubicacion}</p>
            <img src="${imagen}"/>`;
    })
    .catch(error => console.error('Error:', error));


//Ejercicio 2
const postList = document.getElementById('postList');
const urlPost = 'https://jsonplaceholder.typicode.com/posts';

fetch(urlPost)
    .then(response => response.json())
    .then(data => {
        const post = data[0];
        const titulo = `${post.title}`;
        postList.innerHTML =
            `<li>${titulo}</li>`;
    })
    .catch(error => console.error('Error:', error));