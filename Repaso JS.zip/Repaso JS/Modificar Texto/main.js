const textoCambiado = document.getElementById('textoOriginal');
textoCambiado.textContent = 'Texto Modificado';