const parrafo = document.getElementById('miParrafo');
console.log(parrafo.textContent); // Muestra Párrafo de prueba