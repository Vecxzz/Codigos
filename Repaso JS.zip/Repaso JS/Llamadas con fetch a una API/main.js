// Hacer una solicitud GET
fetch('https://api.github.com/users/octocat')
  .then(response => response.json()) // Convertir la respuesta a JSON
  .then(data => console.log(data)) // Mostrar los datos en la consola
  .catch(error => console.error('Error:', error)); // Manejar errores