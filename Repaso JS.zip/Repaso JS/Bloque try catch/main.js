try {
    // Código que puede causar un error
    const resultado = JSON.parse('{"nombre": "Juan"}');
    console.log(resultado.nombre);
} catch (error) {
    console.log('Error al analizar JSON:', error);
}