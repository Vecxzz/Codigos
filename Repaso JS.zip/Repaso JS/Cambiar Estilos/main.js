const caja = document.getElementById('cuadro');
caja.style.backgroundColor = 'yellow';
caja.style.width = 150;