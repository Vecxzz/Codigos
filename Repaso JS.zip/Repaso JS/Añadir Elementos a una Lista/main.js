const miLista = document.getElementById('miLista');
const elementos = ['Item 1', 'Item 2', 'Item 3']

for (let i = 0; i < elementos.length; i++) {
    const nuevoElemento = document.createElement('li');
    nuevoElemento.textContent = elementos[i];
    miLista.appendChild(nuevoElemento);
}