// Crear una promesa
const miPromesa = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('Datos cargados');
    }, 3000);
});

// Usar la promesa
miPromesa.then((resultado) => {
    console.log(resultado); // Muestra el resultado despues de 3 segundos
})