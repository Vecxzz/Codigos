// Función Asíncrona
async function obtenerDatos() {
    const miPromesa = new Promise((resolve) => {
        setTimeout(() => resolve('Hola Mundo'), 1000);
    });

    const resultado = await miPromesa;
    console.log(resultado); // Muestra "Hola mundo" después de 1 segundo
}

// Llamar a la función
obtenerDatos();