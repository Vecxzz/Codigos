const elementos = document.querySelectorAll('.box')
elementos.forEach(elemento => {
    console.log(elemento.textContent)
})