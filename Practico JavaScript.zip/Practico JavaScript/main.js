// // 1. Introducción a JavaScript
// // Ejercicio 2
// let a = 20;
// let b = 2;
// let c = a + b;

// console.log("La suma de a y b es: ", c);

// // Ejercicio 3
// let nombre = prompt("¿Cuál es tu nombre?");
// console.log("Hola, " + nombre + "!")

// // 2. Operadores Lógicos y Condicionales
// // Ejercicio 1
// let d = 10;
// let e = 20;
// let f = 15;

// if (d > e && e > f) {
//   console.log("El mayor de los tres números es: " + d);
// } else if (e > d && e > f) {
//   console.log("El mayor de los tres números es: " + e);
// } else {
//   console.log("El mayor de los tres números es: " + f);
// }

// // Ejercicio 2
// let numeroIngresado = prompt("Ingresa un número y te dire si es par o impar");

// if (numeroIngresado % 2 === 0) {
//   console.log("El número " + numeroIngresado + ", es par");
// } else {
//   console.log("El número " + numeroIngresado + ", es impar");
// }

// // 3. Operadores de Asignación y Bucles
// // Ejercicio 1
// let contador = 10;
// while (contador != 0) {
//   console.log(contador);
//   contador--
// }

// // Ejercicio 2
// let num;

// do {
//   num = prompt("Ingresa un número mayor a 100");
//   num = Number(num);
// } while (num < 100);

// console.log("Ingresaste un número mayor a 100: " + num);

// // 4. Funciones de JavaScript
// // Ejercicio 1
// function esPar(num) {
//   return num % 2 === 0;
// }

// console.log("El número 8 es par: " + esPar(8));
// console.log("El número 7 es par: " + esPar(7));

// // Ejercicio 2
// function convertirCelciusAFarenheit(gCelcius) {
//   return (gCelcius * 1.8 + 32);
// }

// console.log("30ºC son quivalentes a " + convertirCelciusAFarenheit(30) + "ºF");

// // 5. Objetos en JavaScript
// // Ejercicio 1
// const persona = {
//   nombre: "Ana",
//   edad: 30,
//   ciudad: "Madrid",

//   cambiarCiudad: function(nuevaCiudad) {
//     this.ciudad = nuevaCiudad;
//   }
// };

// console.log("Datos antes de cambiar de ciudad:");
// console.log("Nombre: " + persona.nombre + ", " + "Edad: " + persona.edad + ", " + "Ciudad: " + persona.ciudad);

// persona.cambiarCiudad("Barcelona")

// console.log("Datos después de cambiar de ciudad:");
// console.log("Nombre: " + persona.nombre + ", " + "Edad: " + persona.edad + ", " + "Ciudad: " + persona.ciudad);

// // Ejercicio 2
// const libro = {
//   titulo: "El Quijote",
//   autor: "Miguel de Cervantes",
//   anio: 1605,

//   esAntiguo: function() {
//     const anioActual = new Date().getFullYear();
//     const diferenciaAnios = anioActual - this.anio;

//     return diferenciaAnios > 10;
//   }
// };

// console.log('El libro "' + libro.titulo + '" es antiguo: ' + libro.esAntiguo());

// // 6. Arrays
// // Ejercicio 1
// const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// console.log("Números originales: " + numeros.join(", "));

// const numerosMultiplicados = numeros.map(numero => numero * 2);
// console.log("Números multiplicados por 2: " + numerosMultiplicados.join(", "));

// // Ejercicio 2
// const pares = [];

// for (let i = 1; i <= 20; i++) {
//   if (i % 2 === 0) {
//     pares.push(i);
//   }
// }

// console.log("Primeros 10 números pares: " + pares.join(", "));

// 7. Introducción al DOM
// Ejercicio 1
const boton = document.querySelector(".cambiarColor-button");
const parrafos = document.querySelectorAll(".parrafo");

boton.addEventListener("click", () => {
  parrafos.forEach((parrafo) => {
    parrafo.style.color = "blue";
  });
});

// Ejercicio 2
const alerta = document.querySelector(".mostrarAlerta-button");
const texto = document.getElementById("texto");

alerta.addEventListener("click", () => {
  const mensaje = texto.value;
  alert("Has ingresado: " + mensaje);
});

// 8. Eventos en el DOM
// Ejercicio 1
const elementos = document.querySelectorAll(".elemento");

elementos.forEach((elemento) => {
  elemento.addEventListener("click", () => {
    console.log(elemento.textContent);
  });
});

// Ejercicio 2
const deshabilitar = document.querySelector(".deshabilitarCampo-button");
const habilitar = document.querySelector(".habilitarCampo-button");
const campo = document.getElementById("campo");

deshabilitar.addEventListener("click", () => {
  campo.disabled = true;
});

habilitar.addEventListener("click", () => {
  campo.disabled = false;
});

// 9. LocalStorage
// Ejercicio 1
document.addEventListener("DOMContentLoaded", () => {
  const formulario = document.getElementById("email-form");
  const correo = document.getElementById("email");
  const correoGuardado = document.getElementById("correoGuardado");

  function displayEmail(email) {
    correoGuardado.innerHTML = `
      <p>Correo guardado: ${email}</p>
      <button id="deleteEmail">Eliminar Correo</button>
    `;
  }

  const storedEmail = localStorage.getItem("email");
  if (storedEmail) {
    displayEmail(storedEmail);
  }

  formulario.addEventListener("submit", (event) => {
    event.preventDefault(); // Evitar el envío del formulario
    const email = correo.value.trim();
    if (email) {
      localStorage.setItem("email", email);
      displayEmail(email);
      correo.value = ""; // Limpiar el campo de entrada
    }
  });

  correoGuardado.addEventListener("click", (event) => {
    if (event.target.id === "deleteEmail") {
      localStorage.removeItem("email");
      correoGuardado.innerHTML = ""; // Limpiar el correo del DOM
    }
  });
});